package com.musicworld.musicmodel;

public class MusicModel {

	String track;
	String artists;
	String movie;
	String music;
	String actors;
	String price;
	String catg;
	
	public MusicModel() {
		super();
	}

	public MusicModel(String track, String artists, String movie, String music, String actors, String price,
			String catg) {
		super();
		this.track = track;
		this.artists = artists;
		this.movie = movie;
		this.music = music;
		this.actors = actors;
		this.price = price;
		this.catg = catg;
	}

	public String getTrack() {
		return track;
	}

	public void setTrack(String track) {
		this.track = track;
	}

	public String getArtists() {
		return artists;
	}

	public void setArtists(String artists) {
		this.artists = artists;
	}

	public String getMovie() {
		return movie;
	}

	public void setMovie(String movie) {
		this.movie = movie;
	}

	public String getMusic() {
		return music;
	}

	public void setMusic(String music) {
		this.music = music;
	}

	public String getActors() {
		return actors;
	}

	public void setActors(String actors) {
		this.actors = actors;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getCatg() {
		return catg;
	}

	public void setCatg(String catg) {
		this.catg = catg;
	}
	 
	
	
	
}

package com.musicworld.musicdao;

import java.util.List;

import com.musicworld.musicmodel.MusicModel;

public interface IMusicDao {

		public List<MusicModel> getAllAlbums();
		
		
}
